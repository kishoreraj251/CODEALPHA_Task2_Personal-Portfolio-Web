import os
import shutil

# Step 1: Set the folder path you want to organize
directory = r'/path/to/your/folder'

# Step 2: Define file types and the folders to move them into
file_types = {
    "Images": ['.jpg', '.jpeg', '.png', '.gif'],
    "Documents": ['.pdf', '.docx', '.txt'],
    "Scripts": ['.py', '.js', '.html'],
    "Archives": ['.zip', '.rar'],
    "Others": []
}

# Step 3: Create a function to organize files
def organize_files(directory):
    # Create folders if they don't exist
    for folder in file_types.keys():
        folder_path = os.path.join(directory, folder)
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

    # Loop through files in the directory
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)

        # Skip directories
        if os.path.isdir(file_path):
            continue

        # Get the file extension
        file_extension = os.path.splitext(filename)[1].lower()

        # Move files to the correct folder based on file type
        moved = False
        for folder, extensions in file_types.items():
            if file_extension in extensions:
                shutil.move(file_path, os.path.join(directory, folder, filename))
                moved = True
                break

        # If no matching extension, move to 'Others' folder
        if not moved:
            shutil.move(file_path, os.path.join(directory, "Others", filename))

# Step 4: Run the organize function
if __name__ == "__main__":
    organize_files(directory)
