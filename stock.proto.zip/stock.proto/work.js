
let portfolio = [];


const API_KEY = 'YOUR_API_KEY'; 
const API_URL = 'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=';

document.getElementById('add-stock-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const symbol = document.getElementById('stock-symbol').value.toUpperCase();
    const quantity = parseInt(document.getElementById('stock-quantity').value);
    const buyPrice = parseFloat(document.getElementById('buy-price').value);

   
    fetch(`${API_URL}${symbol}&apikey=${API_KEY}`)
        .then(response => response.json())
        .then(data => {
            const currentPrice = parseFloat(data['Global Quote']['05. price']);

          
            const stock = { symbol, quantity, buyPrice, currentPrice };
            portfolio.push(stock);
            renderPortfolio();
        })
        .catch(error => alert('Failed to fetch stock data. Try again later.'));
});

function renderPortfolio() {
    const tableBody = document.querySelector('#portfolio-table tbody');
    tableBody.innerHTML = ''; 

    portfolio.forEach((stock, index) => {
        const change = ((stock.currentPrice - stock.buyPrice) / stock.buyPrice * 100).toFixed(2);
        
        const row = `
            <tr>
                <td>${stock.symbol}</td>
                <td>${stock.quantity}</td>
                <td>$${stock.buyPrice.toFixed(2)}</td>
                <td>$${stock.currentPrice.toFixed(2)}</td>
                <td class="${change >= 0 ? 'green' : 'red'}">${change}%</td>
                <td><button onclick="removeStock(${index})">Remove</button></td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

function removeStock(index) {
    portfolio.splice(index, 1);
    renderPortfolio(); 
}
